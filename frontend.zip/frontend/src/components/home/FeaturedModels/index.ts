export {

    default

} from "./FeaturedModels";