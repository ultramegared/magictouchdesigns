export {

    default

} from "./Hero";