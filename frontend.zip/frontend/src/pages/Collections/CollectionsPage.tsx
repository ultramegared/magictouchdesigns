/**
 * ================================================================
 * Author: ultramegared
 * Project: Magic Touch Designs
 * File: CollectionsPage.tsx
 * Module: Frontend
 * Language: TypeScript React
 * Description:
 * Collections page.
 * ================================================================
 */

import "./CollectionsPage.css";

import Header from "../../components/layout/Header";
import Footer from "../../components/home/Footer";

function CollectionsPage() {

    const collections = [
        {
            id: 1,
            name: "Premium",
            image: "/images/collections/collection-1.jpg"
        },
        {
            id: 2,
            name: "Classic",
            image: "/images/collections/collection-2.jpg"
        },
        {
            id: 3,
            name: "Marble",
            image: "/images/collections/collection-3.jpg"
        },
        {
            id: 4,
            name: "Personalized",
            image: "/images/collections/collection-4.jpg"
        },
        {
            id: 5,
            name: "Seasonal",
            image: "/images/collections/collection-5.jpg"
        },
        {
            id: 6,
            name: "Best Sellers",
            image: "/images/collections/collection-6.jpg"
        },
        {
            id: 7,
            name: "Floral",
            image: "/images/collections/collection-7.jpg"
        },
        {
            id: 8,
            name: "Minimalist",
            image: "/images/collections/collection-8.jpg"
        }
    ];

    const benefits = [
        {
            id: 1,
            title: "PREMIUM QUALITY",
            description: "Top quality materials and long lasting prints.",
            icon: (
                <svg
                    viewBox="0 0 64 64"
                    aria-hidden="true"
                >
                    <path
                        d="M32 7L39 20L53 22L43 32L46 46L32 39L18 46L21 32L11 22L25 20Z"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.5"
                        strokeLinejoin="round"
                    />

                    <circle
                        cx="32"
                        cy="29"
                        r="5"
                        fill="currentColor"
                    />
                </svg>
            )
        },
        {
            id: 2,
            title: "FAST SHIPPING",
            description: "Fast and secure shipping to your door.",
            icon: (
                <svg
                    viewBox="0 0 64 64"
                    aria-hidden="true"
                >
                    <path
                        d="M7 17H39V43H7Z"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                        strokeLinejoin="round"
                    />

                    <path
                        d="M39 25H49L57 34V43H39Z"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                        strokeLinejoin="round"
                    />

                    <circle
                        cx="19"
                        cy="48"
                        r="5"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                    />

                    <circle
                        cx="47"
                        cy="48"
                        r="5"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                    />
                </svg>
            )
        },
        {
            id: 3,
            title: "CUSTOM DESIGNS",
            description: "Create your own design and make it unique.",
            icon: (
                <svg
                    viewBox="0 0 64 64"
                    aria-hidden="true"
                >
                    <path
                        d="M11 53L17 38L43 12L52 21L26 47Z"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                        strokeLinejoin="round"
                    />

                    <path
                        d="M38 17L47 26"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                    />

                    <path
                        d="M11 53L25 48"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                    />
                </svg>
            )
        },
        {
            id: 4,
            title: "SECURE PAYMENT",
            description: "100% secure payments and data protection.",
            icon: (
                <svg
                    viewBox="0 0 64 64"
                    aria-hidden="true"
                >
                    <path
                        d="M32 7L52 14V29C52 42 44 52 32 57C20 52 12 42 12 29V14Z"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                        strokeLinejoin="round"
                    />

                    <path
                        d="M21 32L29 40L44 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    />
                </svg>
            )
        }
    ];

    return (
        <>
            <Header />

            <main className="collections-page">

                {/* ==================================================
                    COLLECTIONS HERO
                   ================================================== */}

                <section className="collections-hero">

                    <div className="collections-hero__background">

                        <img
                            src="/images/collections/collections-hero.jpg"
                            alt="Magic Touch Designs collections"
                        />

                    </div>

                    <div className="collections-hero__overlay"></div>

                    <div className="collections-hero__content">

                        <span className="collections-hero__eyebrow">
                            COLLECTIONS
                        </span>

                        <h1>
                            Explore Our
                            <span>Collections</span>
                        </h1>

                        <p>
                            Discover unique styles for every occasion.
                            Each collection is carefully designed to
                            match your style and every special moment.
                        </p>

                        <button
                            className="collections-hero__button"
                            type="button"
                        >
                            VIEW ALL COLLECTIONS
                            <span aria-hidden="true">›</span>
                        </button>

                    </div>

                </section>

                {/* ==================================================
                    BROWSE BY COLLECTION
                   ================================================== */}

                <section className="collections-browse">

                    <div className="collections-section-heading">

                        <span>
                            BROWSE BY
                        </span>

                        <strong>
                            COLLECTION
                        </strong>

                        <p>
                            Each collection is carefully designed to
                            match your style and every special moment.
                        </p>

                    </div>

                    <div className="collections-grid">

                        {collections.map((collection) => (

                            <article
                                className="collection-card"
                                key={collection.id}
                            >

                                <div className="collection-card__image">

                                    <img
                                        src={collection.image}
                                        alt={`${collection.name} collection`}
                                    />

                                </div>

                                <div className="collection-card__content">

                                    <h2>
                                        {collection.name}
                                    </h2>

                                    <button
                                        className="collection-card__button"
                                        type="button"
                                    >
                                        VIEW COLLECTION

                                        <span aria-hidden="true">
                                            →
                                        </span>

                                    </button>

                                </div>

                            </article>

                        ))}

                    </div>

                    {/* ==================================================
                        COLLECTION BENEFITS
                       ================================================== */}

                    <div className="collections-benefits">

                        {benefits.map((benefit) => (

                            <article
                                className="collection-benefit"
                                key={benefit.id}
                            >

                                <div className="collection-benefit__icon">
                                    {benefit.icon}
                                </div>

                                <div className="collection-benefit__content">

                                    <h3>
                                        {benefit.title}
                                    </h3>

                                    <p>
                                        {benefit.description}
                                    </p>

                                </div>

                            </article>

                        ))}

                    </div>

                </section>

            </main>

            <Footer />
        </>
    );
}

export default CollectionsPage;